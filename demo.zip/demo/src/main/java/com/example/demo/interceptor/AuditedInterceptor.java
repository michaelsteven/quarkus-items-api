package com.example.demo.interceptor;

import java.util.Arrays;

import javax.annotation.Priority;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;


@Priority(42)
@Audited
@Interceptor
//@ApplicationScoped
public class AuditedInterceptor {

	
	private ObjectMapper objectMapper;
	
	/**
	 * Constructor
	 * 
	 * @param objectMapper
	 */
	public AuditedInterceptor(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}
	
	
	@AroundInvoke
	public Object auditMethod(InvocationContext ctx) throws Exception {
		Logger logger = this.getLogger(ctx);
		
		logger.trace("Entered Audited: {} () with arguments = {}" , 
				ctx.getMethod().getName(),
				Arrays.deepToString(ctx.getParameters()));
	    try {
	    	Object object = ctx.proceed();
	    	logger.trace("Exited Audited: {} () with result = {}", 
	    			ctx.getMethod().getName(), objectMapper.writeValueAsString(object)
	    		);
	    	return object;
	    } catch( Exception e) {
	    	logger.error("Exception Audited {} in {}()", Arrays.toString(ctx.getParameters()),
	    			ctx.getMethod().getName()
	    		);
	    	throw e;
	    }
	}
	
	
	Logger getLogger(InvocationContext ctx) {
		return LoggerFactory.getLogger(ctx.getTarget().getClass());
	}
}
