package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.interceptor.AuditedInterceptor;
import com.github.michaelsteven.archetype.springboot.items.Application;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		//SpringApplication.run(DemoApplication.class, args);
		
		//	       SeContainer container = SeContainerInitializer.newInstance()
	    //    .enableInterceptors(AuditedInterceptor.class).initialize();
	
	
	   SpringApplication app = new SpringApplication(DemoApplication.class);
	   app.addInitializers(new ApplicationContextInitializer<ConfigurableApplicationContext>() {

	     @Override
	     public void initialize(ConfigurableApplicationContext applicationContext) {
//
       new Weld()
	       .enableInterceptors(AuditedInterceptor.class)
	      // .addBeanClass(AuditedInterceptor.class)
	       
	       .initialize();
//	       
//
	     }

	   });
	   app.run(args);

	}

}
