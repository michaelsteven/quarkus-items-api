package com.example.demo.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.HelloResponse;

@RestController
public class HelloWorldController {
    @GetMapping(value = "/api/v1/hello", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HelloResponse> sayHello(){
    	HelloResponse helloResponse = new HelloResponse();
    	helloResponse.setValue("Hello world");
    	return ResponseEntity.ok(helloResponse);
	}
    
}
